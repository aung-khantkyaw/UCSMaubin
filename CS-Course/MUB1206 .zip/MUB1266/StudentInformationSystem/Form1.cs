using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace StudentInformationSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Show()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\StudentInformationSystem.mdf;Integrated Security=True;");
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand("Select * from Student", conn);
            SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            dataGridView.DataSource = dataTable;
            conn.Close();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            int id = 1;
            txtId.Text = id.ToString();
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\StudentInformationSystem.mdf;Integrated Security=True;");
            conn.Open();
            SqlCommand selectAll = new SqlCommand("Select * from Student", conn);
            SqlDataReader reader = selectAll.ExecuteReader();
            while (reader.Read())
            {
                id = Convert.ToInt32(reader["Student_Id"]);
                id++;
                txtId.Text = id.ToString();
            }
            Regex emailRex = new Regex(@"[a-zA-Z]+@[a-zA-Z]+.com$");
            Regex ContactRex = new Regex(@"^(09)[0-9]{9}$");
            bool isEmailValid = emailRex.IsMatch(txtEmail.Text);
            bool isContactValid = ContactRex.IsMatch(txtContact.Text);
            String gender = "";
            if (rdoMale.Checked)
            {
                gender = "Male";
            }
            else if (rdoFemale.Checked)
            {
                gender = "Female";
            }
            dateTimePicker.Format = DateTimePickerFormat.Custom;
            dateTimePicker.CustomFormat = "MM/dd/yy HH:MM:ss";
            if (!isEmailValid)
            {
                MessageBox.Show("Please Check Email Address");
            }
            else if (!isContactValid)
            {
                MessageBox.Show("Please Check Contact Number");
            }
            else
            {
                if (txtName.Text != "" && txtEmail.Text != "" && txtContact.Text != "" &&
               txtAddress.Text != "")
                {
                    SqlConnection conn1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\StudentInformationSystem.mdf;Integrated Security=True;");
                    conn1.Open();
                    try
                    {
                        String sql = "insert into Student (Name, Gender, DOB, Email, Address, Contact) values('" + txtName.Text + "', '" + gender + "', '" + dateTimePicker.Text + "' , '" + txtEmail.Text + "' , '" + txtAddress.Text + "' , '" + txtContact.Text + "')";
                        SqlCommand sqlCommand = new SqlCommand(sql, conn1);
                        sqlCommand.ExecuteNonQuery();
                        MessageBox.Show("Insert Successful");
                        txtName.Text = "";
                        txtEmail.Text = "";
                        txtContact.Text = "";
                        txtAddress.Text = "";
                        dateTimePicker.Text = "";
                        rdoFemale.Checked = false;
                        rdoMale.Checked = false;
                        id++;
                        txtId.Text = id.ToString();
                        Show();
                    }
                    catch (SqlException exp)
                    {
                        MessageBox.Show(exp.Message);
                    }
                    conn1.Close();
                }
                else
                {
                    MessageBox.Show("Check Your data.");
                }
            }
            conn.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Show();
            int id = 1;
            txtId.Text = id.ToString();
            dateTimePicker.Format = DateTimePickerFormat.Custom;
            dateTimePicker.CustomFormat = "MM/dd/yy HH:MM:ss";
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\StudentInformationSystem.mdf;Integrated Security=True;");
            conn.Open();
            SqlCommand selectAll = new SqlCommand("Select * from Student", conn);
            SqlDataReader reader = selectAll.ExecuteReader();
            while (reader.Read())
            {
                id = Convert.ToInt32(reader["Student_Id"]);
                id++;
                txtId.Text = id.ToString();
            }
            conn.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Regex emailRex = new Regex(@"[a-zA-Z]+@[a-zA-Z]+.com$");
            Regex ContactRex = new Regex(@"^(09)[0-9]{9}$");
            bool isEmailValid = emailRex.IsMatch(txtEmail.Text);
            bool isContactValid = ContactRex.IsMatch(txtContact.Text);
            String gender = "";
            if (rdoMale.Checked)
            {
                gender = "Male";
            }
            else if (rdoFemale.Checked)
            {
                gender = "Female";
            }
            dateTimePicker.Format = DateTimePickerFormat.Custom;
            dateTimePicker.CustomFormat = "MM/dd/yy HH:MM:ss";
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\StudentInformationSystem.mdf;Integrated Security=True;");
            conn.Open();
            try
            {
                if (!isEmailValid)
                {
                    MessageBox.Show("Please Check Email Address");
                }
                else if (!isContactValid)
                {
                    MessageBox.Show("Please Check Contact Number");
                }
                else
                {
                    String sql = "update Student set Name = '" + txtName.Text + "' , Gender = '" + gender + "' , DOB = '" + dateTimePicker.Text + "' , Email = '" + txtEmail.Text + "' , Contact = '" + txtContact.Text + "' , Address = '" + txtAddress.Text + "' where Student_Id = '" + txtId.Text + "'";
                    SqlCommand sqlCommand = new SqlCommand(sql, conn);
                    sqlCommand.ExecuteNonQuery();
                    MessageBox.Show("Update Successful");
                    txtName.Text = "";
                    txtEmail.Text = "";
                    txtContact.Text = "";
                    txtAddress.Text = "";
                    rdoFemale.Checked = false;
                    rdoMale.Checked = false;
                    dateTimePicker.Text = "";
                    int id = 1;
                    SqlCommand selectAll = new SqlCommand("Select * from Student", conn);
                    SqlDataReader reader = selectAll.ExecuteReader();
                    while (reader.Read())
                    {
                        id = Convert.ToInt32(reader["Student_Id"]);
                        id++;
                        txtId.Text = id.ToString();
                    }
                    Show();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView.Rows[e.RowIndex].Cells[0].Value != null)
                {
                    dataGridView.CurrentRow.Selected = true;
                    txtId.Text = dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                    txtName.Text = dataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                    String gender = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                    if (gender.Equals("Male"))
                    {
                        rdoMale.Checked = true;
                    }
                    else if (gender.Equals("Female"))
                    {
                        rdoFemale.Checked = true;
                    }
                    dateTimePicker.Text = dataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
                    txtEmail.Text = dataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
                    txtAddress.Text = dataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
                    txtContact.Text = dataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\StudentInformationSystem.mdf;Integrated Security=True;");
            conn.Open();
            try
            {
                String sql = "Delete from Student where Student_Id = '" + txtId.Text + "'";
                SqlCommand sqlCommand = new SqlCommand(sql, conn);
                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                MessageBox.Show("Delete Successful");
                txtName.Text = "";
                txtEmail.Text = "";
                txtContact.Text = "";
                txtAddress.Text = "";
                rdoFemale.Checked = false;
                rdoMale.Checked = false;
                dateTimePicker.Text = "";
                dataReader.Close();
                int id = 1;
                SqlCommand selectAll = new SqlCommand("Select * from Student", conn);
                SqlDataReader reader = selectAll.ExecuteReader();
                while (reader.Read())
                {
                    id = Convert.ToInt32(reader["Student_Id"]);
                    id++;
                    txtId.Text = id.ToString();
                }
                Show();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
